﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOrtizA2_1LL
{
    public partial class frmMain : Form
    {
        LinkedList<double> myList = new LinkedList<double>();
        public frmMain()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double sum = 0.0;
            foreach (double n in myList)
            {
                sum = sum + n;
            }
            sum = sum / myList.Count();
            MessageBox.Show(sum.ToString());
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            double rando = 0.0;
            lbxList.Items.Clear();
            myList.Clear();
            for (int i = 0; i < 10; i++)
            {
                rando = rnd.Next(1, 20);
                myList.AddLast(rando);
            }
            foreach (double n in myList)
            {
                lbxList.Items.Add(n);
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            double rem;
            string selected;
            selected = lbxList.SelectedItem.ToString();
            rem = double.Parse(selected);
            if (myList.Remove(rem))
            {
                lbxList.Items.Clear();
                foreach (double n in myList)
                {
                    lbxList.Items.Add(n);
                }
            }
            else
            {
                MessageBox.Show("Item Was Not Found");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            double sum = 0.0;
            foreach (double n in myList)
            {
                sum = sum + n;
            }
            MessageBox.Show(sum.ToString());
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            if (myList.Count == 0)
            {
                MessageBox.Show("**ERROR NO ITEMS IN LIST");

            }
            else
            myList.Clear();
            lbxList.Items.Clear();
        }
    }
}
